import os
import django
from django.db.models import Q

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()
from main_app.models import Profile, Order


# Import your models here
# Create and run your queries within functions

def get_profiles(search_string=None):
    if search_string is not None:
        profiles = Profile.objects.filter(
            Q(full_name__icontains=search_string) |
            Q(email__icontains=search_string) |
            Q(phone_number__icontains=search_string)
        )
        if profiles.exists():
            profiles.order_by('full_name')
            res = []
            for p in profiles:
                res.append(f"Profile: {p.full_name}, email: {p.email}, phone number: {p.phone_number}, orders: {p.orders.count()}")
            return '\n'.join(res)
        return ''
    return ''

def get_loyal_profiles():
    loyal_profiles = Profile.objects.get_regular_customers()
    if loyal_profiles.exists():
        res = []
        for p in loyal_profiles:
            res.append(f"Profile: {p.full_name}, orders: {p.orders.count()}")

        return '\n'.join(res)
    return ''




def get_last_sold_products():
    last_sold_products = Order.objects.prefetch_related('products').order_by('-creation_date')
    if last_sold_products:
        for order in last_sold_products:
            products_in_order = order.products.all()
            res = []
            for product in products_in_order:
                res.append(product.name)

            return f"Last sold products: {', '.join(res)}"
    return ''


print(get_last_sold_products())