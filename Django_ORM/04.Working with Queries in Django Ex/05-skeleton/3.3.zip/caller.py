import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models
from main_app.models import ArtworkGallery, ChessPlayer, Meal, Dungeon, Workout, Laptop


# Create and check models
# Run and print your queries
# TODO fix problem  in judge
def show_highest_rated_art():
    highest_rated_art = ArtworkGallery.objects.order_by('-rating', 'id').first()
    return f"{highest_rated_art.art_name} is the highest rated art with {highest_rated_art.rating} rating!"


def bulk_create_arts(first_art, second_art):
    ArtworkGallery.objects.bulk_create([first_art, second_art])


def delete_negative_rated_arts():
    ArtworkGallery.objects.filter(rating__lt=0).delete()


# artwork1 = ArtworkGallery(artist_name="Vincent van Gogh", art_name="Starry Night",
#
# rating=4, price=1200000.0)
#
# artwork2 = ArtworkGallery(artist_name="Leonardo da Vinci", art_name="Mona Lisa",
#
# rating=5, price=1500000.0)
#
# bulk_create_arts(artwork1, artwork2)
#
# print(show_highest_rated_art())
#
# print(ArtworkGallery.objects.all())


def show_most_expensive_laptop():
    most_expensive_laptop = Laptop.objects.order_by('-price', 'id').first()
    return f"{most_expensive_laptop.brand} is the most expensive laptop available for {most_expensive_laptop.price}$!"


# Todo fix none objects in list
def bulk_create_laptops(laptops):
    Laptop.objects.bulk_create(laptops)


#
# laptop1 = Laptop(brand='Asus',processor='Intel Core i5', memory=8, storage=256, operation_system='Windows',
#                  price=899.99)
# laptop2 = Laptop(brand='Apple',processor='Apple M1', memory=16, storage=512, operation_system='MacOS', price=1399.99)
# laptop3 = Laptop(brand='Lenovo',processor='AMD Ryzen 7', memory=12, storage=512, operation_system='Linux',
#                  price=999.99)
# laptops_to_create = [laptop1, laptop2, laptop3]
# bulk_create_laptops(laptops_to_create)
def update_to_512_GB_storage():
    laptops_to_update = Laptop.objects.filter(brand__in=['Asus', 'Lenovo'])
    laptops_to_update.update(storage=512)


def update_to_16_GB_memory():
    laptops_to_update = Laptop.objects.filter(brand__in=['Apple', 'Dell', 'Acer'])
    laptops_to_update.update(memory=16)


def update_operation_systems():
    brand_to_os = {
        'Asus': 'Windows',
        'Apple': 'MacOS',
        'Dell': 'Linux',
        'Lenovo': 'Chrome OS',
    }

    laptops = Laptop.objects.all()
    for laptop in laptops:
        brand = laptop.brand
        if brand in brand_to_os:
            laptop.operation_system = brand_to_os[brand]
            laptop.save()


def delete_inexpencive_laptops():
    Laptop.objects.filter(price__lt=1200).delete()


# update_to_512_GB_storage()
# update_operation_systems()
# asus_laptop = Laptop.objects.filter(brand__exact='Asus').get()
# lenovo_laptop = Laptop.objects.filter(brand__exact='Lenovo').get()
# print(asus_laptop.storage)
# print(lenovo_laptop.operation_system)

def bulk_create_chess_players(args):
    ChessPlayer.objects.bulk_create(args)


def delete_chess_players():
    ChessPlayer.objects.filter(title__in=['no title']).delete()


def change_chess_games_won():
    ChessPlayer.objects.filter(title__in=['GM']).update(games_won=3)


def change_chess_games_lost():
    ChessPlayer.objects.filter(title__in=['no title']).update(games_lost=25)


def change_chess_games_drawn():
    ChessPlayer.objects.all().update(games_drawn=10)


def grand_chess_title_GM():
    ChessPlayer.objects.filter(rating__gte=2400).update(title='GM')

def grand_chess_title_IM():
    ChessPlayer.objects.filter(rating__range=(2300,2399)).update(title='IM')


def grand_chess_title_FM():
    ChessPlayer.objects.filter(rating__range=(2200, 2299)).update(title='FM')

def grand_chess_title_regular_player():
    ChessPlayer.objects.filter(rating__range=(0, 2200)).update(title='regular player')


def set_new_chefs():
    meal_to_chef = {
        'Breakfast': 'Gordon Ramsay',
        'Lunch': 'Julia Child',
        'Dinner': 'Jamie Oliver',
        'Snack':'Thomas Keller'
    }

    for meal in Meal.objects.all():
        meal_type = meal.meal_type
        if meal_type in meal_to_chef:
            meal.chef = meal_to_chef[meal_type]
            meal.save()
def set_new_preparation_times():
    meal_to_preparation_time = {
        'Breakfast': '10 minutes',
        'Lunch': '12 minutes',
        'Dinner': '15 minutes',
        'Snack':'5 minutes'
    }

    for meal in Meal.objects.all():
        meal_type = meal.meal_type
        if meal_type in meal_to_preparation_time:
            meal.preparation_time = meal_to_preparation_time[meal_type]
            meal.save()
def update_low_calorie_meals():
    Meal.objects.filter(meal_type__in=['Breakfast', 'Dinner']).update(calories=400)


def update_high_calorie_meals():
    Meal.objects.filter(meal_type__in=['Lunch', 'Snack']).update(calories=700)

def delete_lunch_and_snack_meals():
    Meal.objects.filter(meal_type__in=['Lunch', 'Snack']).delete()
